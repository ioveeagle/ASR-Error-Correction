
extern const float tcos[CEP_DIM+1][FILTERNO+1];
